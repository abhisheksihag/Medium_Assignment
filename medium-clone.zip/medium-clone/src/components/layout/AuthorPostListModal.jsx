import React from "react";
import { Modal, ModalOverlay, ModalBody, ModalContent, VStack } from "@chakra-ui/react";
import PostCard from "./PostCard";

const AuthorPostListModal = ({ isOpen, onClose, meetData }) => {
  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <ModalOverlay />
      <ModalContent minW="40vw" maxH="70vh" overflowY="scroll">
        <ModalBody>
          <VStack align="flex-start">
            {meetData
              ? meetData.map((post) => <PostCard key={post.id} post={post} />)
              : null}
          </VStack>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
};

export default AuthorPostListModal;
