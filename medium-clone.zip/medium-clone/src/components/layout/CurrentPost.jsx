import React from "react";
import { Container, Heading, Divider, Grid, GridItem } from "@chakra-ui/react";
import { motion } from "framer-motion";
import { Link as routerLink, useParams } from "react-router-dom";
import { AiOutlineRollback } from "react-icons/ai";
import { ROOT } from "../../lib/routes";
import Navbar from "./Navbar";
import PostCard from "./PostCard";

export default function CurrentPost() {
  const { postId } = useParams();

  const currentPost = dummyData.find((post) => post.id === postId);

  return (
    <>
      <AuthorPostListModal isOpen={isOpen} onClose={onClose} meetData={dummyData} />
      <Navbar />
      <motion.div layout>
        <Container maxW={"7xl"} p="12">
          {}
          <Heading as="h2">{currentPost.title}</Heading>

          <Divider marginTop="5" />
          <Grid templateColumns="repeat(auto-fill, minmax(100%, 1fr))" gap={6} marginTop="5">
            <GridItem>
              <Box w="100%">
                {}
                <PostCard post={currentPost} onClick={onOpen} />
              </Box>
            </GridItem>
          </Grid>
        </Container>
      </motion.div>
    </>
  );
}
