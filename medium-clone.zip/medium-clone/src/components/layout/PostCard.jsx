import React from "react";
import { VStack, Box, Flex, Avatar, Heading, Image, Text, Button } from "@chakra-ui/react";

const PostCard = ({ post, onClick }) => {
  return (
    <VStack align="flex-start">
      <Box py={5}>
        <Flex>
          <Avatar mr={5}>
            <Image src={post.imageUrl} alt="Author Image" />
          </Avatar>
          <Box>
            <Heading size="sm">{post.title}</Heading>
            <span> {post.desc} </span>
          </Box>
        </Flex>
      </Box>
      {onClick && <Button colorScheme="linkedin" onClick={onClick}>Check all posts by author</Button>}
    </VStack>
  );
};

export default PostCard;
