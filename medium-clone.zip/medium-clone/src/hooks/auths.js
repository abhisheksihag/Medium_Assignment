import {
	signInWithEmailAndPassword,
	createUserWithEmailAndPassword,
} from "firebase/auth";
import { useAuthState, useSignOut } from "react-firebase-hooks/auth";
import { useEffect, useState } from "react";
import { useToast } from "@chakra-ui/react";
import { useNavigate } from "react-router-dom";
import { LOGIN, ROOT } from "../lib/routes";
import isUsernameExists from "../utils/isUsernameExists";
import axios from "axios";

// This code is for fatching User data
export function useAuth() {
	//const [authUser, authLoading, error] = useAuthState(auth);
	const [isLoading, setLoading] = useState(false);
	const [user, setUser] = useState("");
	let error=false;

	useEffect(() => {
		async function fetchData() {
			axios.get("http://localhost:3000/myprofile")
      .then((response) => setData(response.data))
      .catch((error) => console.error("Error fetching data:", error));
		}

		if (!authLoading) {
			if (authUser) fetchData();
			else setLoading(false); // Not signed in
		}
	}, [authLoading]);

	return {user, isLoading, error };
}

export function useLogin() {
	const [isLoading, setLoading] = useState(false);
	const toast = useToast();
	const navigate = useNavigate();

	async function login({ email, password, redirectTo = ROOT }) {
		//setLoading(true);
		setLoading(false);
		navigate(redirectTo);
		toast({
			title: "You are logged in",
			status: "success",
			isClosable: true,
			position: "top",
			duration: 5000,
		});
		try {
		    await signInWithEmailAndPassword(auth, email, password);
		    toast({
		        title: "You are logged in",
		        status: "success",
		        isClosable: true,
		        position: "top",
		        duration: 5000,
		    });
		    navigate(redirectTo);
		} catch (error) {
		    toast({
		        title: "Logging in failed",
		        description: error.message,
		        status: "error",
		        isClosable: true,
		        position: "top",
		        duration: 5000,
		    });
		    setLoading(false);
		} finally {
		    setLoading(false);
		}
	}

	return { login, isLoading };
}

export function useLogout() {
	const [signOut, isLoading, error] = useSignOut(auth);
	const toast = useToast();
	const navigate = useNavigate();

	async function logout() {
		if (await signOut()) {
			toast({
				title: "Successfully logged out",
				status: "success",
				isClosable: true,
				position: "top",
				duration: 5000,
			});
			navigate(LOGIN);
		}
		else {
		    toast({
		        title: "Having difficulty to logging out of you ",
		        status: "warning",
		        isClosable: true,
		        position: "bottom-left",
		        duration: 5000,
		    });
	}

	return { logout, isLoading };
}}

export function useRegister() {
	const [isLoading, setLoading] = useState(false);
	const toast = useToast();
	const navigate = useNavigate();

	async function register({
		username,
		email,
		password,
		redirectTo = DASHBOARD,
	}) {
		setLoading(true);

		const usernameExists = await isUsernameExists(username);

		if (usernameExists) {
			toast({
				title: "Username already exists",
				status: "error",
				isClosable: true,
				position: "top",
				duration: 5000,
			});
			setLoading(false);
		} else {
			try {
				const res = await createUserWithEmailAndPassword(
					auth,
					email,
					password
				);

			

				toast({
					title: "Account created",
					description: "You are logged in",
					status: "success",
					isClosable: true,
					position: "top",
					duration: 5000,
				});

				navigate(redirectTo);
			} catch (error) {
				toast({
					title: "Signing Up failed",
					description: error.message,
					status: "error",
					isClosable: true,
					position: "top",
					duration: 5000,
				});
			} finally {
				setLoading(false);
			}
		}
	}

	return { register, isLoading };
}
